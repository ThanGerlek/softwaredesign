

export enum Justification {	Left, Center, Right }
