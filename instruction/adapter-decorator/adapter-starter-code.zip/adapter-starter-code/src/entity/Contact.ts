
export class Contact {

	firstName: string;
	lastName: string;
	phone: string;
	email: string;
	
	constructor(firstName: string, lastName: string, phone: string, email: string) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.email = email;
	}
	
}
