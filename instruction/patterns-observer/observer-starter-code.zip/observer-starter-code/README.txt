Observer Pattern Starter Code
-----------------------------

To execute this starter code, run the following commands from the terminal:

    > npm install
    > npx ts-node src/FlightMonitor.ts

The FlightMonitor program will then output information about a (randomly selected) airline flight every 60 seconds. You should see output that looks something like:

Once you have the code executing correctly, please follow the instructions on Canvas to complete and submit the exercise.
