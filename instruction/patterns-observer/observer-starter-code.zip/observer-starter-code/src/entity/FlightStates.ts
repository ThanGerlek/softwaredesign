import { Flight } from "./Flight";

export class FlightStates {
  time = 0;
  states: Flight[] = [];
}
