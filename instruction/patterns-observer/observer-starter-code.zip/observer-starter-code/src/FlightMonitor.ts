import { FlightFeed } from "./FlightFeed";

main();

function main() {
  let feed = new FlightFeed();
  feed.start();
}
