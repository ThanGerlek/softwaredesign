export class HalloweenYardOrnamentProvider {

    getOrnament(): string {
        return "jack-o-lantern";
    }
}
