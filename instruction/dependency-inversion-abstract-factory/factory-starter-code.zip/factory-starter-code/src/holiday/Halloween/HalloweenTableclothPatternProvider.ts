export class HalloweenTableclothPatternProvider {

    getTablecloth(): string {
        return "ghosts and skeletons";
    }
}
