export class HalloweenWallHangingProvider {

    getHanging(): string {
        return "spider-web";
    }
}
