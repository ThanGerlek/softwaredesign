Jordan's training priority: 3
Clara's training priority: 9
Calvin's training priority: 10

Jordan needs the least training, although it rarely purrs. It fortunately does not climb furniture.
Calvin needs the most training. It is grumpy and rarely purrs. It fortunately does not climb furniture.

Clifford's training priority: 2
Corinne's training priority: 3
Lily's training priority: 7

Clifford needs the least training, but will need to be watched closely since it likes to chase cats. It is well behaved and does not jump on people.
Lily needs the most training. It chases cats and must be watched closely. It does not jump on people but is mean in more subtle ways.
